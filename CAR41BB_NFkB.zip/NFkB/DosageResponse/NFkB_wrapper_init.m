% Includes a proper intialization procedure
parameters = [ 1, 500, 69, 42, 67, 134, 67, 134, 134, 67, 0.002, 1000, ...
               2.5e-4, 0, 1.5e-3, 0.0, 1.67e-3, 1, 0, 1, 0, 0.01, 0, 1.7e-2, ...
               0.01, 9.4, 0.1*0.12, 0.2*0.015, 2.04e-2, 4.556, 0.00075, 0.67, 8e-5, 1125, ...
               2e-4, 1.5, 1.38e-2, 1.67e-2, 2.5e-5, 4.1e-3 ];  


% Initialize the system, letting all species equilibrate before antigen
% exposure

ant_diss = logspace(-0.5,2.5,5);
timepoints_init = (0:1:9500)';           
parameters_init = parameters;
parameters_init(1) = 0;
[~, ~, species_out, observables_out_init] = NFkB_model(timepoints_init, parameters_init);
species_init = species_out(end,:);

% Run with antigen stimulation
timepoints = (0:0.01:6000)';
IKK_maxima = zeros(size(ant_diss));
IKK_times  = zeros(size(ant_diss));
NFkB_maxima  = zeros(size(ant_diss));
NFkB_times   = zeros(size(ant_diss));
NFkB_avgs    = zeros(size(ant_diss));

for ind=1:length(ant_diss)
    
            
    species_init(1) = ant_diss(ind); % With init.'s pre-specified, antigen conc. has to be assigned manually
    parameters(1) = ant_diss(ind);
    [~, tpts, ~, observables_out] = NFkB_model(timepoints, parameters, species_init);
    
    [max_IKK, ind_IKK] = max(observables_out(:,8));
    IKK_a_argmax = tpts(ind_IKK)/60; % Normalize to get minutes
    IKK_maxima(ind) = max_IKK;
    IKK_times(ind) = IKK_a_argmax;
    
    [max_NFkB, ind_NFkB] = max(observables_out(:,end));
    NFkB_argmax = tpts(ind_NFkB)/60; % Normalize to get minutes
    NFkB_maxima(ind) = max_NFkB;
    NFkB_times(ind)  = NFkB_argmax;
    NFkB_avgs(ind)   = mean(observables_out(:,end));
    
    figure(1)
    plot( tpts/60, observables_out(:,8), ":", 'color', [ind/10,0, (1-ind/10)] )
    xlabel("Time, minutes")
    xlim([0 100])
    ylabel("IKK\beta_{active} concentration,  molec. per \mum^2")
    title("IKK\beta_{active} concentration through time")
    %set(gca,'FontName','Menlo','fontsize',30)
    hold on
    
    figure(2)
    plot(tpts/60, observables_out(:,end), ":k", 'color', [ind/10,0, (1-ind/10)] )
    xlabel("Time, minutes")
    xlim([0 100])
    ylabel("NF\kappaB_{n} concentration,  molec. per \mum^2")
    title("NF\kappaB_{n} concentration through time")
    %set(gca,'FontName','Menlo','fontsize',30)
    hold on
    

end



figure(3)
semilogx(ant_diss, 100*IKK_maxima/134)
xlim([0.3162 316.2278])
ylabel("IKK\beta_{active} max. conc., % of total pool")
xlabel("Antigen conc., molec. per \mum^2")
title("IKK\beta_{active} max. conc. vs. antigen conc.")
set(gca,'FontName','Menlo','fontsize',28)
hold on

figure(4) 
semilogx(ant_diss, IKK_times)
xlim([0.3162 316.2278])
ylabel("IKK\beta_{active} peak timing, min")
xlabel("Antigen conc., molec. per \mum^2")
title("IKK\beta_{active} peak timing vs. antigen conc.")
set(gca,'FontName','Menlo','fontsize',28)
hold on

figure(5)
semilogx(ant_diss, 100*NFkB_maxima/67)
xlim([0.3162 316.2278])
ylabel("NF\kappaB_n max. conc., % of total pool")
xlabel("Antigen conc., molec. per \mum^2")
title("NF\kappaB_n max. conc. vs. antigen conc.")
set(gca,'FontName','Menlo','fontsize',28)
hold on

figure(6)
semilogx(ant_diss, NFkB_times)
xlim([0.3162 316.2278])
ylabel("NF\kappaB_n peak timing, min")
xlabel("Antigen conc., molec. per \mum^2")
title("NF\kappaB_n peak timing vs. antigen conc.")
set(gca,'FontName','Menlo','fontsize',28)
hold on

