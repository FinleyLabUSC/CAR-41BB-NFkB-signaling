function [timespan, data_pts] = NFkB_master_wrapper_fcn(X,runnum)

parameters = [ 10, 500, 69, 42, 67, 134, 67, 134, 134, 67, 0.002, 1000, ...
               2.5e-4, 0, 1.5e-3, 0.0, 1.67e-3, 1, 0, 1, 0, 0.01, 0, 1.7e-2, ...
               0.01, 9.4, 0.1*0.12, 0.2*0.015, 2.04e-2, 4.556, 0.00075, 0.67, 8e-5, 1125, ...
               2e-4, 1.5, 1.38e-2, 1.67e-2, 2.5e-5, 4.1e-3 ];
 

parameters(2) = 10.^X(runnum,1); % CAR_CD137_I
parameters(3) = 10.^X(runnum,2); % TRAF2_I
parameters(4) = 10.^X(runnum,3); % RIP1_I
parameters(5) = 10.^X(runnum,4); % TAB2_I
parameters(6) = 10.^X(runnum,5); % NEMO_I
parameters(7) = 10.^X(runnum,6); % TAK1_I
parameters(8) = 10.^X(runnum,7); % IKKb_I
parameters(9) = 10.^X(runnum,8); % IKBa_C_I
parameters(10) = 10.^X(runnum,9); % NFkB_C_I

[timespan, observed_species] = NFkB_wrapper_init_fcn(parameters);
IKKb_trace = observed_species(:,8);
NFkB_trace = observed_species(:,16);

[IKKb_peak_val, IKKb_peak_time] = max(IKKb_trace);
[NFkB_peak_val, NFkB_peak_time] = max(NFkB_trace);

data_pts(1,1) = IKKb_peak_val;
data_pts(1,2) = IKKb_peak_time;

data_pts(2,1) = NFkB_peak_val;
data_pts(2,2) = NFkB_peak_time;

data_pts = data_pts';
      
end

    

