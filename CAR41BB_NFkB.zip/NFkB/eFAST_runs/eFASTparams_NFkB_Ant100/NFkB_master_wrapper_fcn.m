function [timespan, data_pts] = NFkB_master_wrapper_fcn(X,runnum)

parameters = [ 100, 500, 69, 42, 67, 134, 67, 134, 134, 67, 0.002, 1000, ...
               2.5e-4, 0, 1.5e-3, 0.0, 1.67e-3, 1, 0, 1, 0, 0.01, 0, 1.7e-2, ...
               0.01, 9.4, 0.1*0.12, 0.2*0.015, 2.04e-2, 4.556, 0.00075, 0.67, 8e-5, 1125, ...
               2e-4, 1.5, 1.38e-2, 1.67e-2, 2.5e-5, 4.1e-3 ];
parameters(11) = 10.^X(runnum,1); % k_ant_f
parameters(12) = 10.^X(runnum,2); % k_ant_d
parameters(13) = 10.^X(runnum,3); % k_car_cd137_traftri_f
parameters(14) = 10.^X(runnum,4); % k_car_cd137_traftri_d
parameters(15) = 10.^X(runnum,5); % k_traftri_rip1_f
parameters(16) = 10.^X(runnum,6); % k_traftri_rip1_d
parameters(17) = 10.^X(runnum,7); % k_rip1_ubq_f
parameters(18) = 10.^X(runnum,8); % k_rip1_tab2_f
parameters(19) = 10.^X(runnum,9); % k_rip1_tab2_d
parameters(20) = 10.^X(runnum,10);% k_rip1_nemo_f

parameters(21) = 10.^X(runnum,11); % k_rip1_nemo_d
parameters(22) = 10.^X(runnum,12); % k_tab2_tak1_f
parameters(23) = 10.^X(runnum,13); % k_tab2_tak1_d
parameters(24) = 10.^X(runnum,14); % k_tak1_act_f
parameters(25) = 10.^X(runnum,15); % k_nemo_ikkb_f
parameters(26) = 10.^X(runnum,16); % k_nemo_ikkb_d
parameters(27) = 10.^X(runnum,17); % k_ikkb_tak1
parameters(28) = 10.^X(runnum,18); % k_ikkb_inh
parameters(29) = 10.^X(runnum,19); % kcat_ikkb_ikba
parameters(30) = 10.^X(runnum,20); % km_ikkb

parameters(31) = 10.^X(runnum,21); % k_ikba_nfkb_f
parameters(32) = 10.^X(runnum,22); % k_ikba_nfkb_d
parameters(33) = 10.^X(runnum,23); % k_nfkb_exp
parameters(34) = 10.^X(runnum,24); % k_nfkb_eq
parameters(35) = 10.^X(runnum,25); % k_ikba_exp
parameters(36) = 10.^X(runnum,26); % k_ikba_eq
parameters(37) = 10.^X(runnum,27); % k_ikba_nfkb_exp
parameters(38) = 10.^X(runnum,28); % k_ikba_deg
parameters(39) = 10.^X(runnum,29); % k_transcript
parameters(40) = 10.^X(runnum,30); % k_translate

[timespan, observed_species] = NFkB_wrapper_init_fcn(parameters);
IKKb_trace = observed_species(:,8);
NFkB_trace = observed_species(:,16);

[IKKb_peak_val, IKKb_peak_time] = max(IKKb_trace);
[NFkB_peak_val, NFkB_peak_time] = max(NFkB_trace);

data_pts(1,1) = IKKb_peak_val;
data_pts(1,2) = IKKb_peak_time;

data_pts(2,1) = NFkB_peak_val;
data_pts(2,2) = NFkB_peak_time;

data_pts = data_pts';
      
end

    

