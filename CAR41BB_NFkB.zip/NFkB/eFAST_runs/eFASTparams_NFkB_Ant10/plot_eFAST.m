% Ryland Mortlock
% Nov 15th, 2018

% eFAST Plotting

clear all

%The variables that are being varied (horizontal axis)
paramLabels = {'k\_ant\_f', 'k\_ant\_d', 'k\_car\_cd137\_traftri\_f', 'k\_car\_cd137\_traftri\_d', 'k\_traftri\_rip1\_f', ...
                 'k\_traftri\_rip1\_d', 'k\_rip1\_ubq\_f', 'k\_rip1\_tab2\_f', 'k\_rip1\_tab2\_d', 'k\_rip1\_nemo\_f', ...
                   'k\_rip1\_nemo\_d', 'k\_tab2\_tak1\_f', 'k\_tab2\_tak1\_d', 'k\_tak1\_act\_f', 'k\_nemo\_ikkb\_f', ...
                     'k\_nemo\_ikkb\_d', 'k\_ikkb\_tak1', 'k\_ikkb\_inh', 'kcat\_ikkb\_ikba', 'km\_ikkb', 'k\_ikba\_nfkb\_f', ...
                       'k\_ikba\_nfkb\_d', 'k\_nfkb\_exp', 'k\_nfkb\_eq','k\_ikba\_exp','k\_ikba\_eq','k\_ikba\_deg', ...
                         'k\_ikba\_nfkb\_exp', 'k\_transcript','k\_translate'};
                     
                     
outputs = { 'IKK\beta_{max}', 'IKK\beta_{time}', 'NF\kappaB_{max}', 'NF\kappaB_{time}'};  

%Label the data for each timepoint
figure_labels = {'eFAST results'};

    
%% Loop through eFAST results for each timepoint and plot Si results

for s = 1:length(figure_labels)
    load ('p_Si_out_data.mat');
    p_Si_out = squeeze(p_Si_out(s,:,:))'; % Corrected
    load ('p_Sti_out_data.mat');
    p_Sti_out = squeeze(p_Sti_out(s,:,:))'; % Corrected
    load ('Si_out_data.mat');
    Si_out = squeeze(Si_out(s,:,:))';
    load ('Sti_out_data.mat');
    Sti_out = squeeze(Sti_out(s,:,:))'; 
    
    time_label = figure_labels(s); %For naming plot and saving file
    time_label = cell2mat(time_label);
    
    dummy_Si_out = Si_out(:,end);
    
    Si_out = Si_out(:,1:end-1);
    
    [a b] = size(Si_out);
    
    Si_out(find(p_Si_out>0.05)) = NaN;
    
    for i = 1:a
        Si_out(i,find(Si_out(i,:)<=dummy_Si_out(i))) = NaN;
    end

    %Create figure - keep all of this the same
    ny = length(outputs);
    nx = length(paramLabels);
    fig2 = figure(2*s-1);
    padded = padarray((Si_out),[1,1],'post');
    p = pcolor(padded);
    colorDepth = 1000;
    colormap(jet(colorDepth));
    set(p, 'Edgecolor','black','LineWidth',2)
    set(gca,'xgrid', 'off', 'ygrid', 'off', 'gridlinestyle', '-', 'Xcolor','k', 'Ycolor', 'k','LineWidth',3);
    set(gca,'FontSize',4, 'FontWeight','bold','Fontname','Arial')
    pbaspect([nx ny 1])
    axis  square;
    axis equal tight;
    colorbar
    caxis ([0  1]);
    set(gca,'XTick',1:1:b);
    set(gca,'YTick',1:1:a);
    set(gcf,'color','white')
    ax = gca;
    XTick = get(ax, 'XTick');
    XTickLabel = get(ax, 'XTickLabel');
    set(ax,'XTick',XTick+0.5)
    set(ax,'XTickLabel',XTickLabel)
    YTick = get(ax, 'YTick');
    YTickLabel = get(ax, 'YTickLabel');
    set(gca,'TickLength',[ 0 0 ])
    set(ax,'YTick',YTick+0.5)
    set(ax,'YTickLabel',YTickLabel)
    set(gca,'XTickLabel',paramLabels,'FontSize',16)
    set(gca,'YTickLabel',outputs,'FontSize',16)
    set(gca,'XTickLabelRotation',90)
    set(gcf, 'renderer', 'painters');
    set(gcf, 'color', 'white');
    f = get(gca,'title');
    set(f,'FontSize',16,'FontWeight','bold')

    %Here are the only things that should be changed
    title(time_label)
    set(gcf, 'PaperUnits', 'inches');
    x_width=16; %Adjust sizes below to make a good image
    y_width=12;
    set(gcf, 'PaperPosition', [1 -1 x_width y_width]);
    %Set file directory below
%     filepath2 = '/Users/Ryland/Dropbox/Ryland Project Folder/Nov 2018 eFAST and PI/Sensitivity Analysis/Figures/PRL limited/Si Heat Maps/';
    baseFileName = sprintf('%s',time_label);
%     fullFileName = fullfile(filepath2, baseFileName);
    saveas(fig2,baseFileName,'png');
    
end

%% Sti heat maps
for s = 1:length(figure_labels)
    
    load ('p_Si_out_data.mat');
    p_Si_out = squeeze(p_Si_out(s,:,:))'; % Corrected
    load ('p_Sti_out_data.mat');
    p_Sti_out = squeeze(p_Sti_out(s,:,:))'; % Corrected
    load ('Si_out_data.mat');
    Si_out = squeeze(Si_out(s,:,:))';
    load ('Sti_out_data.mat');
    Sti_out = squeeze(Sti_out(s,:,:))'; 
     
    
    time_label = figure_labels(s); %For naming plot and saving file
    time_label = cell2mat(time_label);
    
    dummy_Sti_out = Sti_out(:,end);
    
    Sti_out = Sti_out(:,1:end-1);
    
    [a b] = size(Sti_out);
    
    Sti_out(find(p_Sti_out>0.05)) = NaN;
    
    %dummy_Sti_out(i)
    for i = 1:a
        Sti_out(i,find(Sti_out(i,:)<=dummy_Sti_out(i))) = NaN;
    end

    %Create figure - keep all of this the same
    ny = length(outputs);
    nx = length(paramLabels);
    fig2 = figure(2*s);
    padded = padarray((Sti_out),[1,1],'post');
    p = pcolor(padded);
    colorDepth = 1000;
    colormap(jet(colorDepth));
    set(p, 'Edgecolor','black','LineWidth',2)
    set(gca,'xgrid', 'off', 'ygrid', 'off', 'gridlinestyle', '-', 'Xcolor','k', 'Ycolor', 'k','LineWidth',3);
    set(gca,'FontSize',4, 'FontWeight','bold','Fontname','Arial')
    pbaspect([nx ny 1])
    axis  square;
    axis equal tight;
    colorbar
    caxis ([0  1]);
    set(gca,'XTick',1:1:b);
    set(gca,'YTick',1:1:a);
    set(gcf,'color','white')
    ax = gca;
    XTick = get(ax, 'XTick');
    XTickLabel = get(ax, 'XTickLabel');
    set(ax,'XTick',XTick+0.5)
    set(ax,'XTickLabel',XTickLabel)
    YTick = get(ax, 'YTick');
    YTickLabel = get(ax, 'YTickLabel');
    set(gca,'TickLength',[ 0 0 ])
    set(ax,'YTick',YTick+0.5)
    set(ax,'YTickLabel',YTickLabel)
    set(gca,'XTickLabel',paramLabels,'FontSize',16)
    set(gca,'YTickLabel',outputs,'FontSize',16)
    set(gca,'XTickLabelRotation',90)
    set(gcf, 'renderer', 'painters');
    set(gcf, 'color', 'white');
    f = get(gca,'title');
    set(f,'FontSize',16,'FontWeight','bold')

    %Here are the only things that should be changed
    title(time_label)
    set(gcf, 'PaperUnits', 'inches');
    x_width=16; %Adjust sizes below to make a good image
    y_width=12;
    set(gcf, 'PaperPosition', [1 -1 x_width y_width]);
    %Set file directory below
 
%     filepath2 = '/Users/Ryland/Dropbox/Ryland Project Folder/Nov 2018 eFAST and PI/Sensitivity Analysis/Figures/PRL limited/Sti Heat Maps/';
    baseFileName = sprintf('%s',time_label);
%     fullFileName = fullfile(filepath2, baseFileName);
    saveas(fig2,baseFileName,'png');
    
end
