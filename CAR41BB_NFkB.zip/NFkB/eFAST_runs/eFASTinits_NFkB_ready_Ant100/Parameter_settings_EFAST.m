global efast_var y_var_label numTimepoints
%% PARAMETER INITIALIZATION
%  set up max and mix matrices for three input variables
%  pmin and pmax has to be of the same length as the 
%  length of the input variables including the dummy.
load('ParamBounds.mat') %%% bounds should only be for the model parameters, 
                             %%% since you are appending pmin and pmax for the 
                             %%% dummy variable
A1 = ParamBounds(:,1);
A2 = ParamBounds(:,2);
pmin = [log10(A1);            %Our parameters
        log10(0.1)];        %Dummy variable
pmax = [log10(A2);                
        log10(10)];
%% Number of timepoints
%%% update here and in the simulation file
numTimepoints = 1; %%% UPDATE TO INCLUDE THE TOTAL NUMBER OF TIMEPOINTS FOR WHICH YOU HAVE DATA
    
%% Input  Labels
%%% labels for the eFAST variables - the parameters whose values you are changing
efast_var = { 'CAR_CD137_I', 'TRAF2_I', 'RIP1_I', 'TAB2_I', ...
                       'NEMO_I', 'TAK1_I', 'IKKb_I', 'IKBa_C_I', 'NFkB_C_I', ...
                                 'dummy'  };       

%% Outputs from the model

%%% labels for the model outputs - the model predicted species' concentrations
y_var_label  = { 'IKKb_{max}', 'IKKb_{time}', 'NFkB_{max}', 'NFkB_{time}'};           
     
