global efast_var y_var_label numTimepoints
%% PARAMETER INITIALIZATION
%  set up max and mix matrices for three input variables
%  pmin and pmax has to be of the same length as the 
%  length of the input variables including the dummy.
load('ParamBounds.mat') %%% bounds should only be for the model parameters, 
                             %%% since you are appending pmin and pmax for the 
                             %%% dummy variable
A1 = ParamBounds(:,1);
A2 = ParamBounds(:,2);
pmin = [log10(A1);            %Our parameters
        log10(0.1)];        %Dummy variable
pmax = [log10(A2);                
        log10(10)];
%% Number of timepoints
%%% update here and in the simulation file
numTimepoints = 1; %%% UPDATE TO INCLUDE THE TOTAL NUMBER OF TIMEPOINTS FOR WHICH YOU HAVE DATA
    
%% Input  Labels
%%% labels for the eFAST variables - the parameters whose values you are changing
efast_var = {'k_ant_f', 'k_ant_d', 'k_car_cd137_traftri_f', 'k_car_cd137_traftri_d', 'k_traftri_rip1_f', ...
              'k_traftri_rip1_d', 'k_rip1_ubq_f', 'k_rip1_tab2_f', 'k_rip1_tab2_d', 'k_rip1_nemo_f', ...
               'k_rip1_nemo_d', 'k_tab2_tak1_f', 'k_tab2_tak1_d', 'k_tak1_act_f', 'k_nemo_ikkb_f', ...
                'k_nemo_ikkb_d', 'k_ikkb_tak1', 'k_ikkb_inh', 'kcat_ikkb_ikba', 'km_ikkb', 'k_ikba_nfkb_f', ...
                 'k_ikba_nfkb_d', 'k_nfkb_exp', 'k_nfkb_eq','k_ikba_exp','k_ikba_eq','k_ikba_deg', ...
                  'k_ikba_nfkb_exp', 'k_transcript', 'k_translate', 'dummy'};   
                         

%% Outputs from the model

%%% labels for the model outputs - the model predicted species' concentrations
y_var_label  = { 'IKKb_{max}', 'IKKb_{time}', 'NFkB_{max}', 'NFkB_{time}'};           
     
