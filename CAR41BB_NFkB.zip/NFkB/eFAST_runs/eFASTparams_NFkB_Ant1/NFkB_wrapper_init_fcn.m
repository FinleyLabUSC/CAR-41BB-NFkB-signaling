function [tpts, observables_out] = NFkB_wrapper_init_fcn(parameters)


    % Initialize the system           
    timepoints_init = (0:0.1:6000)';           
    parameters_init = parameters;
    parameters_init(1) = 0;
    [~, ~, species_out, observables_out_init] = NFkB_model(timepoints_init, parameters_init);
    species_init = species_out(end,:);

    % Run with antigen stimulation
    timepoints = (0:0.1:8000)';
    species_init(1) = parameters(1); % With init.'s specified, antigen conc. has to be assined manually
    [~, tpts, ~, observables_out] = NFkB_model(timepoints, parameters, species_init);

    
end
  