%% This script produces the bar plots for Fig. 6A,B and Fig. S2

mutinfo_vec_1 = [0.9826, 0.9843, 0.9778, 0.7857, 0.9822, 1.2110,  0.9840,  0.9975, 0.9902, 0.7858, 1.2090]; % First entry is default MI (bits) for noise level 0.75, the rest are overexpression cases
mutinfo_vec_2 = [0.9826, 0.9702, 0.9654, 1.4080, 0.9815, 0.6519,  0.9816,  1.0410, 1.0030, 1.4080, 0.6548]; % First entry is default MI (bits) for noise level 0.75, the rest are underexpression cases
mutinfo_vec_3 = [3.5558, 2.2410, 1.3778, 0.9826, 0.7851, 0.4780;...
                 4.2008, 3.0645, 2.1857, 1.7787, 1.5578, 0.8093]; % First line is default MI (bits) for all noise levels, the second for disabled IKKb deactivation 

mutinfo_perc_1 = 100*(mutinfo_vec_1-mutinfo_vec_1(1))/mutinfo_vec_1(1);
mutinfo_perc_2 = 100*(mutinfo_vec_2-mutinfo_vec_2(1))/mutinfo_vec_2(1);
mutinfo_perc_3 = 100*(mutinfo_vec_3(2,:)-mutinfo_vec_3(1,:))./mutinfo_vec_3(1,:);

figure(1)
bar(mutinfo_perc_1(2:end))
title("MI with 50% overexpressed signaling proteins")
xlim([0.5 10.5])
ylim([-50 50])
xticks([1 2 3 4 5 6 7 8 9 10])
xticklabels([ "TRAF2"; "RIP1"; "TAB2"; "TAK1"; "NEMO"; "IKK\beta"; "IkB\alpha"; "NF\kappaB"; 'TAB2/TAK1'; 'NEMO/IKK\beta'])
ylabel("MI change relative to default, %")
xtickangle(25)

figure(2)
bar(mutinfo_perc_2(2:end))
title("MI with 50% underexpressed signaling proteins")
xlim([0.5 10.5])
ylim([-50 50])
xticks([1 2 3 4 5 6 7 8 9 10])
xticklabels([ "TRAF2"; "RIP1"; "TAB2"; "TAK1"; "NEMO"; "IKK\beta"; "IkB\alpha"; "NF\kappaB"; 'TAB2/TAK1'; 'NEMO/IKK\beta'])
ylabel("MI change relative to default, %")
xtickangle(25)

figure(3)
bar(mutinfo_perc_3)
title("MI with disbaled IKK\beta deactivation")
xlim([0.5 6.5])
ylim([0 105])
xticks([1 2 3 4 5 6])
xlabel("Noise level")
xticklabels([ "0.1"; "0.25"; "0.50"; "0.75"; "1.0"; "2.0"])
ylabel("MI change relative to default, %")
